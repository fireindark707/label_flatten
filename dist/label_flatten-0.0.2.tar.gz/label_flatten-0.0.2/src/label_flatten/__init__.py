from label_flatten.node import Node
from label_flatten.tree import Tree